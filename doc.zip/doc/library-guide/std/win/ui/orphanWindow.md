# orphanWindow

orphanWindow 是 aardio 实现的一种全新的窗口模式。

orphanWindow 即悬浮窗口，指的将普通的控件子窗口（ child window ）孤立出来成为独立的从属窗口（ [owned window](basic.md#parent-vs-owner) ），但是仍然可以显示在原来的位置，如影随形的跟随父窗口移动、显示、隐藏，在视觉上模拟类似嵌入式子窗口的效果。

- 可以模拟并代替子窗口，但可以不被其他子窗口遮挡，不受父窗口显示区域的限制，可以凸出显示在父窗口边框之外。
- 可以将外部进程窗口通过附加到 orphanWindow 嵌入 aardio 窗口，避免修改外部窗口的父窗口带来的潜在问题，又能模拟出类似的效果。

请参考: [范例](../../../../example/Windows/Basics/orphanWindow.html)

orphanWindow 用法很简单：

- 首先在窗体设计器中拖好控件的位置（控件可以拖到窗口的外面）
- 然后调用控件的 `orphanWindow(transparent,hwndBuddy)` 函数就行了。所有参数都是可选的，通常不必指定参数。
    * transparent 指定是否转换为分层辽明窗口（ plus 控件可以支持 ）。
    * 可选用 hwndBuddy 参数指定为外部窗口句柄，就可以将外部进程窗口通过附加到 orphanWindow，成为吸附在 aardio 窗口上的伪子窗口。这可以用来解决一些比较复杂的问题，实现一些难以实现的效果。例如 ruffle.exe 运行时以独立窗口播放动画，将这个外部进程的独立窗口嵌入为子窗口时会带来很多问题。而 aardio 的 process.ruffle 扩展库使用 orphanWindow 实现了一个动画控件，可以非常方便地将 ruffle 窗口嵌入到 aardio 窗口中作为普通控件使用。

orphanWindow 可以用来实现一些有趣的效果。例如传统的控件前后重叠显示有较多的限制，plus 控件的透背景效果实现上也是通过剪切背景模拟出来的（ 也就是剪切父窗口相同的区域作为自己的背景，本质上不透明但可以模拟出透明的效果 ），所以无法重叠在其他控件（ 仅在父窗口背景上绘图的 bk,bkplus 等无句柄控件除外 ）前面并且还能保持透明。但转换为 orphanWindow 就可以突破这些限制，可以让 plus 控件显示在其他控件之前还能保持透明效果。
